# Loop Printer

Print your Loop pages or use save to PDF for your exports.
Currently in BETA.

Works with one page only for the time being.

## Updates
- We are not live on Microsoft Edge
- https://microsoftedge.microsoft.com/addons/detail/loop-printer-beta/jocapjbbganclnpmmcnjedkmejmgepnd
- Get your Chrome extension
- https://chromewebstore.google.com/detail/loop-printer-beta/focjonfjfbmcjfnepjngmjdlliilkofb?hl=en&authuser=2&pli=1

## TO-DO
- Implement cascading done linked pages (1 level)
- Better formatting of tables